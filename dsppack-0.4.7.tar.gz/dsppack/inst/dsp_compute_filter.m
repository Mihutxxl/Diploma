## -*- texinfo -*-
## @deftypefn {Function File} {[@var{b}, @var{a}] =} dsp_compute_filter (@var{Fs}, @var{Fc}, @var{Fc2}, @var{N}, @var{type_idx}, @var{topo_idx}, @var{arch_idx})
## Compute filter coefficients from UI parameters.
## @var{arch_idx}: 1=IIR (default), 2=FIR
## @var{type_idx}: 1=lowpass, 2=highpass, 3=bandpass, 4=bandstop
## IIR @var{topo_idx}: 1=Butterworth, 2=Chebyshev I, 3=Chebyshev II, 4=Elliptic
## FIR @var{topo_idx}: 1=Hamming, 2=Hanning, 3=Blackman, 4=Kaiser, 5=Parks-McClellan, 6=Least-Squares
## @end deftypefn

function [b, a] = dsp_compute_filter(Fs, Fc, Fc2, N, type_idx, topo_idx, arch_idx)
    if nargin < 7; arch_idx = 1; end

    type_strs = {"low", "high", "bandpass", "stop"};
    type_str  = type_strs{type_idx};

    if type_idx <= 2
        Wn = Fc / (Fs / 2);
    else
        Wn = [Fc, Fc2] / (Fs / 2);
    end

    if arch_idx == 1
        % ---- IIR ----
        switch topo_idx
            case 1
                [b, a] = butter(N, Wn, type_str);
            case 2
                [b, a] = cheby1(N, 3, Wn, type_str);
            case 3
                [b, a] = cheby2(N, 40, Wn, type_str);
            case 4
                [b, a] = ellip(N, 3, 40, Wn, type_str);
        end
    else
        % ---- FIR ----
        a = 1;

        if topo_idx <= 4
            switch topo_idx
                case 1; win = hamming(N + 1);
                case 2; win = hanning(N + 1);
                case 3; win = blackman(N + 1);
                case 4; win = kaiser(N + 1, 5);
            end
            if type_idx == 2
                b = fir1(N, Wn, "high", win);
            elseif type_idx == 4
                b = fir1(N, Wn, "stop", win);
            else
                b = fir1(N, Wn, win);
            end
        else
            [fb, ab] = make_pm_bands(Wn, type_idx);
            if topo_idx == 5
                b = firpm(N, fb, ab);
            else
                b = firls(N, fb, ab);
            end
        end
    end
end

function [f, amp] = make_pm_bands(Wn, type_idx)
    tw = 0.05;
    switch type_idx
        case 1
            f   = [0, max(0.001, Wn - tw), min(0.999, Wn + tw), 1];
            amp = [1, 1, 0, 0];
        case 2
            f   = [0, max(0.001, Wn - tw), min(0.999, Wn + tw), 1];
            amp = [0, 0, 1, 1];
        case 3
            f   = [0, max(0.001, Wn(1) - tw), Wn(1), Wn(2), min(0.999, Wn(2) + tw), 1];
            amp = [0, 0, 1, 1, 0, 0];
        case 4
            f   = [0, Wn(1), min(Wn(1) + tw, Wn(2) - tw), ...
                   max(Wn(1) + tw, Wn(2) - tw), Wn(2), 1];
            amp = [1, 1, 0, 0, 1, 1];
    end
end

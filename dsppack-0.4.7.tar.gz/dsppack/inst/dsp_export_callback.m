function dsp_export_callback(h)
    % Read inputs
    Fs       = str2double(get(h.edit_Fs,    "string"));
    Fc       = str2double(get(h.edit_Fc,    "string"));
    Fc2      = str2double(get(h.edit_Fc2,   "string"));
    N        = str2double(get(h.edit_Order, "string"));
    type_idx = get(h.popup_Type, "value");
    topo_idx = get(h.popup_Topo, "value");
    arch_idx = get(h.popup_Arch, "value");

    % Compute filter using shared function
    [b, a] = dsp_compute_filter(Fs, Fc, Fc2, N, type_idx, topo_idx, arch_idx);

    % Export to base workspace
    assignin("base", "num_coeffs", b);
    assignin("base", "den_coeffs", a);
    assignin("base", "fs_val",     Fs);

    msgbox("Exported to workspace: 'num_coeffs', 'den_coeffs', 'fs_val'.", "Export Successful");
end

function dsp_design_callback(h)
    % 1. Extract inputs
    Fs       = str2double(get(h.edit_Fs,    "string"));
    Fc       = str2double(get(h.edit_Fc,    "string"));
    Fc2      = str2double(get(h.edit_Fc2,   "string"));
    N        = str2double(get(h.edit_Order, "string"));
    type_idx = get(h.popup_Type, "value");
    topo_idx = get(h.popup_Topo, "value");
    arch_idx = get(h.popup_Arch, "value");

    % 2. Validation
    if isnan(Fs) || isnan(Fc) || isnan(N)
        errordlg("Please enter valid numbers for Fs, Fc, and Order."); return;
    end
    if Fc >= Fs/2
        errordlg("Cutoff Fc must be less than Nyquist frequency (Fs/2)."); return;
    end
    if type_idx >= 3
        if isnan(Fc2) || Fc2 >= Fs/2 || Fc2 <= Fc
            errordlg("For Band Pass/Stop, Fc2 must satisfy: Fc < Fc2 < Fs/2."); return;
        end
    end

    % 3. Compute filter using shared function
    [b, a] = dsp_compute_filter(Fs, Fc, Fc2, N, type_idx, topo_idx, arch_idx);

    % 4. Persist coefficients so the analysis window always reflects
    %    the last-designed filter (whether from here or the P/Z editor)
    h.last_b = b;
    h.last_a = a;
    guidata(h.fig, h);

    % 5. Plot magnitude and phase responses
    dsp_plot_response(h.ax_mag, h.ax_phase, b, a, Fs);

    % 5b. Draw specification mask if enabled
    if isfield(h, "chk_mask") && get(h.chk_mask, "value")
        Rp = str2double(get(h.edit_Rp, "string"));
        Rs = str2double(get(h.edit_Rs, "string"));
        if isnan(Rp); Rp = 1; end
        if isnan(Rs); Rs = 40; end
        dsp_draw_mask(h.ax_mag, b, a, Fs, Fc, Fc2, type_idx, Rp, Rs);
    end

    % 6. Update stability indicator
    s = dsp_check_stability(b, a);
    if s.stable
        set(h.txt_stability, ...
            "String", sprintf("STABLE  |  max pole radius: %.4f  |  margin: %.4f", s.max_radius, s.margin), ...
            "BackgroundColor", [0.18, 0.72, 0.25], "ForegroundColor", [1, 1, 1]);
    else
        set(h.txt_stability, ...
            "String", sprintf("%s  |  max pole radius: %.4f", s.status, s.max_radius), ...
            "BackgroundColor", [0.85, 0.15, 0.15], "ForegroundColor", [1, 1, 1]);
    end
end

function dsp_export_callback(h)
    % 1. Re-calculate the filter (or retrieve stored values if you saved them)
    % For simplicity, we re-read the inputs to ensure we export exactly what is on screen.
    Fs = str2double(get(h.edit_Fs, "string"));
    Fc = str2double(get(h.edit_Fc, "string"));
    N  = str2double(get(h.edit_Order, "string"));
    type_idx = get(h.popup_Type, "value");

    Wn = Fc / (Fs/2);
    if type_idx == 1
        [b, a] = butter(N, Wn, "low");
    else
        [b, a] = butter(N, Wn, "high");
    end

    % 2. Push variables to the Base Workspace
    % 'assignin' is the magic command that sends data to the main window
    assignin("base", "num_coeffs", b);
    assignin("base", "den_coeffs", a);
    assignin("base", "fs_val", Fs);

    % 3. Confirm to user
    msgbox("Filter coefficients exported as 'num_coeffs' and 'den_coeffs'.", "Success");
end

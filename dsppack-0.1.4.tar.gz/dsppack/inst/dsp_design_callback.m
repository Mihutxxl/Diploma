function dsp_design_callback(h)
    % 1. Extract inputs
    Fs = str2double(get(h.edit_Fs, "string"));
    Fc = str2double(get(h.edit_Fc, "string"));
    N  = str2double(get(h.edit_Order, "string"));
    type_idx = get(h.popup_Type, "value"); % 1=Low, 2=High

    % 2. Validation
    if isnan(Fs) || isnan(Fc) || isnan(N)
        errordlg("Please enter valid numbers."); return;
    end
    if Fc >= Fs/2
        errordlg("Cutoff must be less than Nyquist (Fs/2)."); return;
    end

    % 3. Calculation
    Wn = Fc / (Fs/2);
    if type_idx == 1
        [b, a] = butter(N, Wn, "low");
    else
        [b, a] = butter(N, Wn, "high");
    end

    % 4. Call Plotter
    dsp_plot_response(h.ax_mag, b, a, Fs);
end

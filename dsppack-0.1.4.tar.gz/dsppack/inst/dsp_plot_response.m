function dsp_plot_response(ax_handle, b, a, Fs)
    % Calculate
    [H, f] = freqz(b, a, 1024, Fs);

    % Plot
    axes(ax_handle);
    plot(f, 20*log10(abs(H)), "LineWidth", 2);
    title("Magnitude Response");
    xlabel("Frequency (Hz)");
    ylabel("Magnitude (dB)");
    grid on;
    xlim([0, Fs/2]);
end

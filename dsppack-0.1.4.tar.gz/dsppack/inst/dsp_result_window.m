function dsp_result_window(parent_fig)
    % 1. Create the new window (Positioned same as the main one)
    h.fig = figure("position", [150, 150, 800, 600], ...
                   "name", "Analysis Results", ...
                   "menubar", "none", ...
                   "numbertitle", "off", ...
                   "resize", "off");

    % 2. Add a "BACK" button
    h.btn_Back = uicontrol(h.fig, "Style", "pushbutton", ...
                           "String", "< BACK", ...
                           "Units", "normalized", ...
                           "Position", [0.02, 0.92, 0.15, 0.06], ...
                           "Callback", @cb_back_wrapper);

    % 3. Add some placeholder content (e.g., a text box)
    uicontrol(h.fig, "Style", "text", "String", "Detailed Analysis Window", ...
              "Units", "normalized", "Position", [0.2, 0.5, 0.6, 0.1], ...
              "FontSize", 20);

    % Store handles
    guidata(h.fig, h);

    % -----------------------------------------------------
    % CALLBACK: The Back Button
    % -----------------------------------------------------
    function cb_back_wrapper(~, ~)
        % 1. Close this current window (Window 2)
        delete(gcf);

        % 2. Make the Parent Window (Window 1) visible again
        if ishandle(parent_fig)
            set(parent_fig, "Visible", "on");
        end
    end
end

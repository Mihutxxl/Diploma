## -*- texinfo -*-
## @deftypefn  {Function File} fdatool_launch ()
## Launches the Filter Design and Analysis Tool GUI.
## @end deftypefn

function dsppack_launch()
    % Check dependencies
    if isempty(pkg("list", "signal"))
        error("The 'signal' package is not loaded. Run 'pkg load signal' first.");
    end

    theme.bg      = [0.1, 0.1, 0.1];  % Dark Gray Background

    % 1. Create the Main Window
    h.fig = figure("position", [100, 100, 1050, 650], ...
                   "name", "FDA Tool - Diploma Project", ...
                   "menubar", "none", ...
                   "numbertitle", "off", ...
                   "resize", "off");#, ...
                   #"Color", theme.bg);

    % 2. Create Left Panel (Inputs)
    h.panel = uipanel("Title", "Filter Specifications", ...
                      "FontSize", 11, ...
                      "Position", [0.02, 0.05, 0.30, 0.92]);

    % -- Sampling Freq (Fs) --
    uicontrol(h.panel, "Style", "text", "String", "Sampling Freq (Fs):", ...
              "Units", "normalized", "Position", [0.05, 0.88, 0.5, 0.05], ...
              "HorizontalAlignment", "left");
    h.edit_Fs = uicontrol(h.panel, "Style", "edit", "String", "44100", ...
                          "Units", "normalized", "Position", [0.60, 0.88, 0.35, 0.06]);

    % -- Cutoff Freq (Fc) --
    uicontrol(h.panel, "Style", "text", "String", "Cutoff Freq (Fc):", ...
              "Units", "normalized", "Position", [0.05, 0.78, 0.5, 0.05], ...
              "HorizontalAlignment", "left");
    h.edit_Fc = uicontrol(h.panel, "Style", "edit", "String", "1000", ...
                          "Units", "normalized", "Position", [0.60, 0.78, 0.35, 0.06]);

    % -- Filter Order (N) --
    uicontrol(h.panel, "Style", "text", "String", "Filter Order (N):", ...
              "Units", "normalized", "Position", [0.05, 0.68, 0.5, 0.05], ...
              "HorizontalAlignment", "left");
    h.edit_Order = uicontrol(h.panel, "Style", "edit", "String", "4", ...
                             "Units", "normalized", "Position", [0.60, 0.68, 0.35, 0.06]);

    % -- Filter Type Dropdown --
    uicontrol(h.panel, "Style", "text", "String", "Filter Type:", ...
              "Units", "normalized", "Position", [0.05, 0.58, 0.4, 0.05], ...
              "HorizontalAlignment", "left");
    h.popup_Type = uicontrol(h.panel, "Style", "popupmenu", ...
                             "String", {"Low Pass", "High Pass"}, ...
                             "Units", "normalized", "Position", [0.05, 0.53, 0.9, 0.06]);

    % -- DESIGN Button --
    h.btn_Design = uicontrol(h.panel, "Style", "pushbutton", "String", "DESIGN FILTER", ...
                             "Units", "normalized", "Position", [0.05, 0.05, 0.9, 0.12], ...
                             "FontSize", 10, "FontWeight", "bold", ...
                             "Callback", @cb_design_wrapper);

    % -- EXPORT Button --
    % We place it slightly below the Design button
    h.btn_Export = uicontrol(h.panel, "Style", "pushbutton", ...
                             "String", "Export to Workspace", ...
                             "Units", "normalized", ...
                             "Position", [0.05, 0.20, 0.9, 0.08], ... % Lower down
                             "Callback", @cb_export_wrapper);     % New callback

    h.btn_Analyze = uicontrol(h.panel, "Style", "pushbutton", ...
                              "String", "DETAILED ANALYSIS >", ...
                              "Units", "normalized", ...
                              "Position", [0.05, 0.35, 0.9, 0.08], ...
                              "Callback", @cb_analyze_wrapper);

    h.btn_Exit = uicontrol(h.fig, "Style", "pushbutton", ...
                           "String", "EXIT", ...
                           "Units", "normalized", ...
                           "Position", [0.85, 0.02, 0.12, 0.06], ... % Bottom-Right coordinates
                           "FontSize", 10, "FontWeight", "bold", ...
                           "ForegroundColor", [0.8, 0, 0], ...       % Red text color
                           "Callback", @cb_exit_wrapper);

    % 3. Create Right Panel (Plotting Area)
    h.ax_mag = axes("Units", "normalized", "Position", [0.40, 0.30, 0.55, 0.60]);
    title("Magnitude Response");
    xlabel("Frequency (Hz)");
    ylabel("Magnitude (dB)");
    grid on;

    % Store handles
    guidata(h.fig, h);

    % 4. Nested Callback Wrapper
    function cb_design_wrapper(src, ~)
        handles = guidata(src);
        % Calls the logic file
        dsp_design_callback(handles);
    end

    function cb_export_wrapper(src, ~)
        handles = guidata(src);
        % Call a new logic function we will write next
        dsp_export_callback(handles);
    end

    function cb_analyze_wrapper(src, ~)
        % 1. Get the handle of the CURRENT window (Window 1)
        current_fig = ancestor(src, "figure");

        % 2. Hide Window 1 (so it looks like it disappeared)
        set(current_fig, "Visible", "off");

        % 3. Launch Window 2 (and pass Window 1's handle so we can find it later)
        dsp_result_window(current_fig);
    end

    function cb_exit_wrapper(~, ~)
        % Create a confirmation dialog
        choice = questdlg("Are you sure you want to exit?", ...
                          "Exit Tool", ...
                          "Yes", "No", "No");

        % If user clicks "Yes", close everything
        if strcmp(choice, "Yes")
            close all;
        end
    end
end

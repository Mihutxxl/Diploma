## -*- texinfo -*-
## @deftypefn {Function File} fda_pz_editor (@var{main_fig}, @var{Fs})
## Interactive Z-Plane pole-zero editor. Places poles and zeros by clicking
## on the Z-plane, enforces complex-conjugate symmetry for real coefficients,
## then submits the resulting filter back to the main FDA Tool window.
## @end deftypefn

function fda_pz_editor(main_fig, Fs)
    snap_thr = 0.05;   % imaginary snap-to-zero threshold (data units)

    % Mutable state shared across all nested callbacks via closure
    state.poles = [];   % column vector of complex pole locations
    state.zeros = [];   % column vector of complex zero locations
    state.mode  = 1;    % 1 = place pole, 0 = place zero

    % -------------------------------------------------------------------
    % Editor figure
    % -------------------------------------------------------------------
    h.fig = figure("position", [160, 80, 560, 660], ...
                   "name", "Interactive P/Z Editor", ...
                   "menubar", "none", ...
                   "numbertitle", "off", ...
                   "resize", "off", ...
                   "CloseRequestFcn", @cb_close);

    % -------------------------------------------------------------------
    % Top control bar
    % -------------------------------------------------------------------
    h.btn_toggle = uicontrol(h.fig, ...
        "Style",           "pushbutton", ...
        "String",          "Mode:  PLACE POLE  [X]", ...
        "Units",           "normalized", ...
        "Position",        [0.04, 0.945, 0.52, 0.042], ...
        "FontWeight",      "bold", ...
        "BackgroundColor", [0.72, 0.18, 0.18], ...
        "ForegroundColor", [1, 1, 1], ...
        "Callback",        @cb_toggle);

    h.btn_clear = uicontrol(h.fig, ...
        "Style",           "pushbutton", ...
        "String",          "Clear All", ...
        "Units",           "normalized", ...
        "Position",        [0.66, 0.945, 0.30, 0.042], ...
        "FontWeight",      "bold", ...
        "BackgroundColor", [0.40, 0.40, 0.40], ...
        "ForegroundColor", [1, 1, 1], ...
        "Callback",        @cb_clear);

    % -------------------------------------------------------------------
    % Z-Plane axes
    % -------------------------------------------------------------------
    h.ax_pz = axes("Parent",   h.fig, ...
                   "Units",    "normalized", ...
                   "Position", [0.12, 0.18, 0.82, 0.73]);

    draw_zplane();   % draw static elements + initial empty state

    % -------------------------------------------------------------------
    % Bottom control bar
    % -------------------------------------------------------------------
    h.btn_submit = uicontrol(h.fig, ...
        "Style",           "pushbutton", ...
        "String",          "SUBMIT & DESIGN", ...
        "Units",           "normalized", ...
        "Position",        [0.04, 0.03, 0.55, 0.09], ...
        "FontSize",        11, ...
        "FontWeight",      "bold", ...
        "BackgroundColor", [0.10, 0.52, 0.18], ...
        "ForegroundColor", [1, 1, 1], ...
        "Callback",        @cb_submit);

    h.btn_cancel = uicontrol(h.fig, ...
        "Style",           "pushbutton", ...
        "String",          "Cancel", ...
        "Units",           "normalized", ...
        "Position",        [0.68, 0.03, 0.28, 0.09], ...
        "FontSize",        10, ...
        "BackgroundColor", [0.60, 0.15, 0.15], ...
        "ForegroundColor", [1, 1, 1], ...
        "Callback",        @cb_close);

    % Register Z-plane click handler on the figure level
    set(h.fig, "WindowButtonDownFcn", @cb_click);

    % ===================================================================
    % Callbacks  (nested — share 'state', 'h', 'main_fig', 'Fs' via closure)
    % ===================================================================

    function cb_toggle(src, ~)
        state.mode = 1 - state.mode;
        if state.mode == 1
            set(src, "String",          "Mode:  PLACE POLE  [X]", ...
                     "BackgroundColor", [0.72, 0.18, 0.18]);
        else
            set(src, "String",          "Mode:  PLACE ZERO  [O]", ...
                     "BackgroundColor", [0.08, 0.52, 0.14]);
        end
    end

    function cb_clear(~, ~)
        state.poles = [];
        state.zeros = [];
        draw_zplane();
    end

    function cb_click(~, ~)
        % Only respond to a plain left-click
        if ~strcmp(get(h.fig, "SelectionType"), "normal")
            return;
        end

        % Read cursor position in Z-plane data coordinates
        cp = get(h.ax_pz, "CurrentPoint");
        cx = cp(1, 1);
        cy = cp(1, 2);

        % Reject clicks outside the axes bounds
        xl = get(h.ax_pz, "XLim");
        yl = get(h.ax_pz, "YLim");
        if cx < xl(1) || cx > xl(2) || cy < yl(1) || cy > yl(2)
            return;
        end

        % Snap near-zero imaginary values to the real axis
        if abs(cy) < snap_thr
            cy = 0;
        end

        pt = cx + 1j * cy;

        if state.mode == 1   % --- place pole ---
            state.poles = [state.poles; pt];
            if cy ~= 0
                state.poles = [state.poles; conj(pt)];
            end
        else                 % --- place zero ---
            state.zeros = [state.zeros; pt];
            if cy ~= 0
                state.zeros = [state.zeros; conj(pt)];
            end
        end

        draw_zplane();
    end

    function cb_submit(~, ~)
        % Convert root locations to polynomial coefficients.
        % poly([]) returns [1], so an empty set gives a trivial coefficient.
        b = real(poly(state.zeros(:).'));
        a = real(poly(state.poles(:).'));

        % Persist coefficients into the main window's guidata so the
        % analysis window picks up these P/Z-derived coefficients
        main_h = guidata(main_fig);
        main_h.last_b = b;
        main_h.last_a = a;
        guidata(main_fig, main_h);

        dsp_plot_response(main_h.ax_mag, main_h.ax_phase, b, a, Fs);

        % Close editor and restore main window
        delete(h.fig);
        set(main_fig, "Visible", "on");
    end

    function cb_close(~, ~)
        % Cancel: just restore the main window without changing its plots
        delete(h.fig);
        set(main_fig, "Visible", "on");
    end

    % ===================================================================
    % Z-Plane drawing helper
    % ===================================================================

    function draw_zplane()
        dsp_draw_zplane(h.ax_pz, state.zeros, state.poles, ...
                        sprintf("Z-Plane  —  Fs = %.0f Hz  (click to place)", Fs));
    end

end

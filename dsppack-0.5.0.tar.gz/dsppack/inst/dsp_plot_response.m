## -*- texinfo -*-
## @deftypefn {Function File} dsp_plot_response (@var{ax_mag}, @var{ax_phase}, @var{b}, @var{a}, @var{Fs})
## Plot the magnitude and phase responses of a digital filter on the
## given axes handles.
## @end deftypefn

function dsp_plot_response(ax_mag, ax_phase, b, a, Fs)
    [H, f] = freqz(b, a, 1024, Fs);

    % Magnitude response
    axes(ax_mag);
    cla;
    plot(f, 20*log10(abs(H)), "LineWidth", 2);
    title("Magnitude Response");
    xlabel("Frequency (Hz)");
    ylabel("Magnitude (dB)");
    grid on;
    xlim([0, Fs/2]);

    % Phase response
    axes(ax_phase);
    cla;
    plot(f, unwrap(angle(H)) * (180 / pi), "LineWidth", 2, "Color", [0.85, 0.33, 0.10]);
    title("Phase Response");
    xlabel("Frequency (Hz)");
    ylabel("Phase (degrees)");
    grid on;
    xlim([0, Fs/2]);
end

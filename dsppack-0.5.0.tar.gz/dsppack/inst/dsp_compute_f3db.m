## -*- texinfo -*-
## @deftypefn {Function File} {@var{str} =} dsp_compute_f3db (@var{H}, @var{f})
## Return a human-readable string describing the -3 dB crossing
## frequencies of a frequency response @var{H} sampled at frequencies
## @var{f} (in Hz).
## @end deftypefn

function f3db_str = dsp_compute_f3db(H, f)
    mag_db = 20 * log10(abs(H));
    max_db = max(mag_db);
    cross  = find(diff(sign(mag_db - (max_db - 3))));
    if ~isempty(cross)
        f3db_str = sprintf("%.1f Hz", f(cross(1)));
        if numel(cross) > 1
            f3db_str = sprintf("%s / %.1f Hz", f3db_str, f(cross(end)));
        end
    else
        f3db_str = "N/A";
    end
end
